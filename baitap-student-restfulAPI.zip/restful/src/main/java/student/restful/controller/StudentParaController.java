package student.restful.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import student.restful.model.Student;

@RestController
@RequestMapping("/student/para")
public class StudentParaController {
	
	@Autowired
	public ArrayList<Student> students;
	
	@GetMapping
	public Object paraStudent(@RequestParam("name") String name, @RequestParam("age") int age) {
		students.add(new Student(name,age));
		return students;
	}
	
}
