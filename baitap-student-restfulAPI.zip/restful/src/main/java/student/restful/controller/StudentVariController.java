package student.restful.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import student.restful.model.Student;

@RestController
@RequestMapping("/student/vari/{name}/{age}")
public class StudentVariController {
	@Autowired
	public ArrayList<Student> students;
	
	@GetMapping
	public Object paraStudent(@PathVariable String name, @PathVariable int age ) {
		students.add(new Student(name,age));
		return students;
	}
}
