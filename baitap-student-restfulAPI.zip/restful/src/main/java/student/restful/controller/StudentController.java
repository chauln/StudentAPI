package student.restful.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import student.restful.model.Student;

@RestController
@RequestMapping("/student/requestbody")
public class StudentController {
	
	@Autowired
	public ArrayList<Student> students;
	
	@GetMapping
	public Object getStudent() {
		return new ResponseEntity<>(students, HttpStatus.OK);
	}
	
	@PostMapping
	public Object saveStudent(@RequestBody Student student) {
		//student = new Student("Nguyen ABC", 30);
		students.add(student);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
