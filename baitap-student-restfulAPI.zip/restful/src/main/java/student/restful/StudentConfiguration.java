package student.restful;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import student.restful.model.Student;

@Configuration
public class StudentConfiguration {
	
	@Bean
	public ArrayList<Student> getStudent() {
		
		return new ArrayList<Student>();
	}
}
